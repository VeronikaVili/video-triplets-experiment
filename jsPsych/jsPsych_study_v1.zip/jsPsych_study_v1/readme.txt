VISUAL FINGERPRINT OF MATERIAL APPEARANCE EXPERIMENT
Version 1

RUN
Just open the experiment.html file, it will open the study in your browser
The jspsych and demo folder need to be at the same place as the file

STRUCTURE OF EXPERIMENT
1. There are 3 screens with instructions, to move to the next press any key on the keyboard
2. 3 test trials
3. 6 experiment trials (4 normal trials and 2 catch trials)
4. End screen with the possibility to show collected data

NOTES
For now experiment features only one video, to demontrate a difference each instance of video is numbered
It is also stated which type of trial is shown (this will be later removed)
Order of videos is randomized
Order of types of trials is also randomized
Preloading of videos is disabled when running via file protocol, video loading may be a little slower than it will be in the actual online experiment 
At the end collected data is shown (this will be later removed)